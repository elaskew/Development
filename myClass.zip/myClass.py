# myClass.py
# Assignment 5 class definition
# Class for operations ( add, subtract, multiply and divide)
# Isreal Askew
# Python 3.11.5
# 10/1/2023

class MathOp:
    def __init__(self):
      self.a = 0
      self.b = 0
      self.result = 0

    # Sum function
    def to_sum(self, a, b):
      self.a = a
      self.b = b
      self.result = self.a + self.b

     # Subtract function
    def to_sub(self, a, b):
      self.a = a
      self.b = b
      self.result = self.a - self.b

    # Multiply function
    def to_mult(self, a, b):
     self.a = a
     self.b = b
     self.result = self.a * self.b

     # Divide function
    def to_div(self, a, b):
      self.a = a
      self.b = b
      self.result = self.a / self.b  if self.b else 0 # check for divide by zero in denominator, if true return 0
    
    def get_add(self):
     print(f'The sum of {self.a} and {self.b} =', self.result)   
    def get_sub(self):
     print(f'The difference of {self.a} and {self.b} is ', self.result)
    def get_mult(self):
     print(f'The product of {self.a} and {self.b} =', self.result)
    def get_div(self):
     print(f'The dividend of {self.a} and {self.b} is ', self.result)


     
