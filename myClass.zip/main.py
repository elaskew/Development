# main.py 
# Assignment 5 main program to execute myClass definition
# Class using functions for each of the operation (subtract, add, multiply and divide)
# Isreal Askew
# Python 3.11.5
# 10/1/2023

import myClass

# Execute until exit or non-numeric value entered
user_quit =""
while user_quit != "EXIT" or user_quit!= "exit":
    user_quit = input('Enter any key to continue or type EXIT: ')
    if user_quit == "EXIT" or user_quit == "exit":
     break    
# Try block to catch non-numerics
    try:
# Get input for a and b
       a = int(input('Enter first number: '))
       b = int(input('Enter second number: '))
    except ValueError:
       print('Only numbers are allowed!')
       break
 
  
 # Create an instance of the myClass to add and show results
    add_it = myClass.MathOp()
    add_it.to_sum(a, b)
    add_it.get_add()
 # Create an instance of the myClass to sub and show results
    sub_it = myClass.MathOp()
    sub_it.to_sub(a, b)
    sub_it.get_sub()
 # Create an instance of the myClass to multiply and show results
    multiply_it = myClass.MathOp()
    multiply_it.to_mult(a, b)
    multiply_it.get_mult()
 # Create an instance of the myClass to divide and show results
    divide_it = myClass.MathOp()
    divide_it.to_div(a, b)
    divide_it.get_div()


   
   